package edu.rockvalleycollege.mytodolist2020


class Message(val id: String, val name: String, val message:String)
